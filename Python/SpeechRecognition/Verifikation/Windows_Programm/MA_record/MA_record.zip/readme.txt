Ausführen:

1. Windows-Taste Drücken und "cmd" oder "Eingabeaufforderung" in die Suche eintippen
2. Eingabeaufforderung öffnen - (schwarzes Fenster sollte nun geöffnet sein)
3. record.exe in die Eingabeaufforderung ziehen und mit Enter bestätigen
4. Device ID auswaehlen ==> in der Liste tauchen mehrere Audiogeräte auf die erste ziffer entspricht der ID, Audiogerät sollte ein INPUT sein. ID eingeben und mit Enter bestätigen
5. 10 Saetze einsprechen jeweils mit Enter quittieren
6. WAV Dateien und NAME.json archivieren und an hannes.dittmann@stud.hshl.de zurücksenden=)
7. Viel Spaß
